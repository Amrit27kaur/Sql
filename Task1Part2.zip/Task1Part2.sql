create database Task1

use Task1
--Create a student table

create table student(S_id varchar(20) not null primary key, Fname varchar(50)not null,Lname varchar(50)not null,Home_Address_Street varchar(50)not null,Home_Address_City varchar(50)not null,Home_Address_Zipcode varchar(50)not null,Date_of_Birth varchar(20)not null,sex varchar(10)not null,Category varchar(20)not null,Nationality varchar(40)not null,Special_Needs varchar(40)not null,Current_Status varchar(30)not null,Comments varchar(50)null,Room_Category varchar(30)not null,A_id varchar(20)not null,Flat_number varchar(20)null,Hall_of_residence varchar(30)null,Contact_id varchar(20)not null);
drop table student;
select * from student;
--insert a data in student table

insert into student values('s1','John','Doe','1 bonnie bras','Brampton','l6y0y5','12-10-1991','male','junior','Canadian','abc','placed','asdffeee','Flat','a1','f1','','c1');

insert into student values('s2','Jani','Due','11 LeaderShip ','Brampton','l5y0y4','11-11-1992','Female','graduate','Indain','abced','waiting','asdffeee','Waiting','a2','','','c2');
insert into student values('s3','Joe','Smith','12 Arrowpoint','Brampton','l5d0y5','12-12-1993','male','sophomore','Pakistan','rff','placed','asdffeee','Hall','a1','','r1','c3');
insert into student values('s4','Marry','Silly','1 Beaconcrest','Brampton','y0y5d4','10-10-1994','Female','junior','Canadian','asde','placed','asdffeee','Flat','a4','f1','','c4');
insert into student values('s5','Mani','Mariam','30 Faywood','Brampton','f6b0b3','09-09-1995','male','graduate','China','sdsd','placed','asdffeee','Hall','a2','','r11','c5');
insert into student values('s6','Anne','Dolly','22 Timbercove','Brampton','l6b8b4','08-08-1996','Female','junior','Canadian','fffg','placed','asdffeee','Flat','a6','f1','','c6');
insert into student values('s7','Aahan','Dubby','14 Breeli','Brampton','a8c0c4','07-07-1997','male','sophomore','Indian','dfeff','placed','asdffeee','Flat','a6','f1','','c7');
insert into student values('s8','Alex','Hebert','23Dusk drive','Brampton','d9y7f4','12-06-1998','male','junior','Canadian','efefr','placed','asdffeee','Flat','a3','f1','','c8');
insert into student values('s9','Petter','Alexdr','15 Tatra','Brampton','j4g8f6','05-10-1991','male','junior','Afganisitan','hthth','placed','asdffeee','Hall','a3','','r2','c9');
insert into student values('s10','Jally','Sina','24 Bittersweet','Brampton','D7f7f9','08-04-1989','Female','graduate','Canadian','rggr','waiting','asdffeee','Waiting','a5','','','c10');


drop table student;

--table of Advisor

create table Advisor(A_id varchar(10)not null primary key,Full_Name varchar(30)not null,Position varchar(30)not null,Name_Of_Dept varchar(30)not null,Phone_Number varchar(30)not null,Office_Location varchar(30)not null,Office_Number varchar(30)not null);
drop table Advisor;
select * from Advisor;

--data of Advisor
insert into Advisor values('a1','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a2','Waliam Sheikh','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a3','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a4','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a5','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a6','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a7','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a8','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a9','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');
insert into Advisor values('a10','Petter Smith','Hall Adminstrator','Hall manager','648-998-9999','Hall','1888-888-3454');

--create table

create table Hall_of_resi(Hall_id varchar(30)not null,Name varchar(30)not null,Address varchar(30)not null,Telephone_Number varchar(30)not null,Manager varchar(30)not null);

select * from Hall_of_resi;

--insert data
insert into Hall_of_resi values('h1','abc','yyyyy','567-7665-0000','Alex');
insert into Hall_of_resi values('h2','def','zzzzz','465-7665-1234','Smith');
insert into Hall_of_resi values('h3','ghi','ooooo','567-0000-5647','Harry');
insert into Hall_of_resi values('h4','jkl','ppppp','365-6666-5678','Nick');
insert into Hall_of_resi values('h5','mno','rrrrr','647-7665-1098','Jones');
insert into Hall_of_resi values('h6','cde','gggg','567-7665-0000','Alexder');
insert into Hall_of_resi values('h7','zab','bbbbb','465-7665-1234','Davy');
insert into Hall_of_resi values('h8','wxy','ccccc','567-0000-5647','Henry');
insert into Hall_of_resi values('h9','stu','qqqqq','365-6666-5678','Doe');
insert into Hall_of_resi values('h10','pqr','mmmmm','647-7665-1098','Jane');

--create data

create table Hall_Of_room(Hall_id varchar(30)not null,Room_no varchar(30)not null,Place_no varchar(30)not null,Monthly_rent varchar(30)not null);

select * from Hall_Of_room;

--insert data
insert into Hall_Of_room values('h1','1','11','1000');
insert into Hall_Of_room values('h1','2','11','1000');
insert into Hall_Of_room values('h1','3','11','1000');
insert into Hall_Of_room values('h2','11','12','1100');
insert into Hall_Of_room values('h2','12','12','1100');
insert into Hall_Of_room values('h3','4','13','1200');
insert into Hall_Of_room values('h3','5','13','1200');
insert into Hall_Of_room values('h4','6','14','1000');
insert into Hall_Of_room values('h4','7','14','1000');
insert into Hall_Of_room values('h5','1','15','800');
insert into Hall_Of_room values('h5','2','15','800');

--create tABLE

create table Flat(Flat_number_id varchar(30)not null,Address varchar(30)not null,Room_number varchar(30)not null);

select * from Flat;

--INSERT table
insert into flat values('f1','aaaa','1');
insert into flat values('f2','bbbb','1');
insert into flat values('f3','cccc','1');
insert into flat values('f4','dddd','1');
insert into flat values('f5','eeee','1');
insert into flat values('f6','ffff','1');
insert into flat values('f7','gggg','1');
insert into flat values('f8','hhhh','1');
insert into flat values('f9','iiii','1');
insert into flat values('f10','jjjj','1');

--create table
create table Lease(Lease_number_id varchar(30)not null,Duration_of_lease varchar(30)not null,Name_of_student varchar(30)not null,S_id varchar(30)not null,Hall_number varchar(30)null default 'null',Flat_number varchar(30)default 'null',Address varchar(30)not null,Date_of_entry varchar(30)not null,leave_entry varchar(30)not null);

select * from Lease;
drop table Lease;

--insert data
insert into Lease values('l1','20-june','Alex','s8','h1','','asdd','27june','30-july');
insert into Lease values('l2','21-june','Jally','s10','','','mmytyt','','');
insert into Lease values('l3','22-june','Jani','s2','','','mtytj','','');
insert into Lease values('l4','23-july','Joe','s3','h1','','jyhjy','27-june','27-july');
insert into Lease values('l5','20-August','Marry','s4','flat','','ikuy','27-august','30-august');
insert into Lease values('l6','11-September','Mani','s5','','h1','errr','17-september','17-octember');
insert into Lease values('l7','20-Oct','Anne','s6','flat','','rrgg','27-oct','27-oct');
insert into Lease values('l8','20-March','Aahan','s7','flat','','aghht','27-March','30-june');
insert into Lease values('l9','20-july','John','s1','','Flat','sddf','27-july','30-august');
insert into Lease values('l10','20-may','petter','s9','h1','','rtewt','27-may','27-june');

--create table

create table Invoice(S_id varchar(30)not null,In_id varchar(30)not null,Quater varchar(30)not null,Payment_due varchar(30)not null,S_Full_Name varchar(30)not null,Flat_Number varchar(30)not null,Address varchar(30)not null,Lease_Number_id varchar(30)not null);
select * from Invoice;
--insert data 

create table Payment(Payment_id varchar(30)not null,In_id varchar(30)not null,S_id varchar(30)not null,Date_of_Payment varchar(30)not null,Method_of_Payment varchar(30)not null,Date_of_First_Remainder varchar(30)not null,Date_of_Second_Remainder varchar(30)not null);
select * from Payment;

create table Student_Flat_Inspection(S_F_id varchar(30)not null, Name_of_Staff varchar(30)not null,Date_of_Inspection varchar(30)not null,Satisfactory_condition varchar(30)not null,Comments varchar(30)not null,Flat_Number varchar(30)not null);
select * from Student_Flat_Inspection;

create table Course(Course_Number_id varchar(30)not null,Course_tittle varchar(30)not null,Year varchar(30)not null,Instructor varchar(30)not null,Room_number varchar(30)not null,Department_name varchar(30)not null);
select * from Course;

create table Accomdation_Staff(Acc_Staff_id varchar(30)not null,Fname varchar(30)not null,Lname varchar(30)not null,Home_Address_Street varchar(50)not null,Home_Address_City varchar(50)not null,Home_Address_Zipcode varchar(50)not null,Date_of_Birth varchar(20)not null,sex varchar(10)not null,Position varchar(20)not null,Location varchar(20)not null);
select * from Accomdation_Staff;

Create table Contact(Contact_id varchar(20)not null, Fname varchar(20)not null, Lname varchar(20)not null,Relation_with_Student varchar(20)not null,Home_Address_Street varchar(50)not null,Home_Address_City varchar(50)not null,Home_Address_Zipcode varchar(50)not null,Phone_no varchar(30)not null); 
select * from Contact;



